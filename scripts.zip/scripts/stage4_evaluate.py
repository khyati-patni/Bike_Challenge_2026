"""
stage4_evaluate.py
───────────────────
Evaluation utilities. Called by stage5_natuke_stages.py.

MODEL SEPARATION (critical):
=============================
cosine_scibert    — pure cosine(SciBERT DOI emb, SciBERT label emb). No graph.
cosine_pubmedbert — pure cosine(PubMedBERT DOI emb, PubMedBERT label emb). No graph.

node2vec     — structure-only graph walk embedding. Scores: cosine(h, t)
metapath2vec — structure-only heterogeneous walk. Scores: dot(h, t)
ephen        — structure-only spectral + text heat kernel. Scores: cosine(h, t)

rgcn         — R-GCN init from SciBERT. Scores: h^T W_r t
rotate       — RotatE init from SciBERT phases. Scores: -||h∘r - t||
transe       — TransE init from SciBERT. Scores: -||h+r-t||
complex      — ComplEx init from SciBERT. Scores: Re(<h, r, conj(t)>)
graphsage    — GraphSAGE init from SciBERT. Scores: h^T W_r t

ensemble     — min-max normalised sum of all BERT-graph models + best cosine

Hits@k for k in {1, 5, 20, 50} (EVAL_K_VALUES from config).
"""
import json, pathlib, sys
import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import TASKS, DATA_DIR, FREQ_PRIOR_POW, EVAL_K_VALUES

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


# ── Ranking metrics ───────────────────────────────────────────────────────────

def hits_at_k(ranked_lists, trues, k):
    return float(np.mean([1 if t in r[:k] else 0
                          for r, t in zip(ranked_lists, trues)]))

def mrr(ranked_lists, trues):
    rrs = []
    for r, t in zip(ranked_lists, trues):
        try:    rrs.append(1.0 / (list(r).index(t) + 1))
        except: rrs.append(0.0)
    return float(np.mean(rrs))


# ── Frequency calibration ─────────────────────────────────────────────────────

def calibrate(scores, labels, train_counts, total):
    cal = scores.copy().astype(float)
    for i, lbl in enumerate(labels):
        freq    = train_counts.get(lbl, 0) / max(total, 1)
        cal[i] -= FREQ_PRIOR_POW * np.log(freq + 1e-9)
    return [labels[j] for j in np.argsort(-cal)]


# ── Scorers ───────────────────────────────────────────────────────────────────

def score_cosine(doi_emb_n, label_emb_n, h_sci_id, cand_sci_ids):
    """Normalised cosine: already L2-normed inputs."""
    d = doi_emb_n[h_sci_id]
    c = label_emb_n[cand_sci_ids]
    return c @ d   # (C,)

def score_rotate(ent_emb, rel_emb, h_id, r_id, cand_ids):
    h = ent_emb[h_id]; r = rel_emb[r_id]; t = ent_emb[cand_ids]
    re_h, im_h = np.cos(h), np.sin(h)
    re_r, im_r = np.cos(r), np.sin(r)
    re_t, im_t = np.cos(t), np.sin(t)
    re_rot = re_h * re_r - im_h * im_r
    im_rot = re_h * im_r + im_h * re_r
    dist = np.sqrt((re_rot - re_t)**2 + (im_rot - im_t)**2 + 1e-9).sum(-1)
    return -dist

def score_transe(ent_emb, rel_emb, h_id, r_id, cand_ids, norm=2):
    h = ent_emb[h_id]; r = rel_emb[r_id]; t = ent_emb[cand_ids]
    diff = h + r - t
    dist = np.sqrt((diff**2).sum(-1) + 1e-9) if norm == 2 else np.abs(diff).sum(-1)
    return -dist

def score_rgcn(node_emb, rel_weights, h_id, r_id, cand_ids):
    h = node_emb[h_id]; t = node_emb[cand_ids]; R = rel_weights[r_id]
    return t @ (h @ R)

def score_complex(ent_emb, rel_emb, h_id, r_id, cand_ids):
    D    = ent_emb.shape[1] // 2
    re_h = ent_emb[h_id, :D];  im_h = ent_emb[h_id, D:]
    re_r = rel_emb[r_id, :D];  im_r = rel_emb[r_id, D:]
    re_t = ent_emb[cand_ids, :D]; im_t = ent_emb[cand_ids, D:]
    return (
        (re_t * (re_h * re_r + im_h * im_r)).sum(-1) +
        (im_t * (re_h * im_r - im_h * re_r)).sum(-1)
    )

def score_graphsage(node_emb, rel_weights, h_id, r_id, cand_ids):
    h = node_emb[h_id]; t = node_emb[cand_ids]; R = rel_weights[r_id]
    return t @ (h @ R)

def score_node2vec(node_emb, h_id, cand_ids):
    """Structure-only: cosine between walk embeddings."""
    h = node_emb[h_id]
    t = node_emb[cand_ids]
    h_n = h / (np.linalg.norm(h) + 1e-9)
    t_n = t / (np.linalg.norm(t, axis=1, keepdims=True) + 1e-9)
    return t_n @ h_n

def score_metapath2vec(node_emb, h_id, cand_ids):
    """Structure-only: dot product between metapath walk embeddings."""
    h = node_emb[h_id]
    t = node_emb[cand_ids]
    return t @ h

def score_ephen(node_emb, h_id, cand_ids):
    """Structure-only: cosine of spectral+text heat-kernel embeddings."""
    h = node_emb[h_id]
    t = node_emb[cand_ids]
    h_n = h / (np.linalg.norm(h) + 1e-9)
    t_n = t / (np.linalg.norm(t, axis=1, keepdims=True) + 1e-9)
    return t_n @ h_n

def minmax_norm(arr):
    mn, mx = arr.min(), arr.max()
    if mx - mn < 1e-9:
        return np.zeros_like(arr)
    return (arr - mn) / (mx - mn)


# ── Main evaluation function ──────────────────────────────────────────────────

def evaluate_one_stage(
    # Cosine baselines — one per encoder, independent
    scibert_doi_emb=None,    scibert_label_emb=None,
    pubmedbert_doi_emb=None, pubmedbert_label_emb=None,
    # Structure-only graph models (no BERT)
    node2vec_node=None,
    metapath2vec_node=None,
    ephen_node=None,
    # BERT-initialised graph models
    rotate_ent=None,   rotate_rel=None,
    rgcn_node=None,    rgcn_rel=None,
    transe_ent=None,   transe_rel=None,
    complex_ent=None,  complex_rel=None,
    graphsage_node=None, graphsage_rel=None,
    # Data overrides for this stage
    train_edges_override=None,
    test_rows_override=None,
):
    """
    Evaluate all models on one stage split.

    Returns:
      { model_name: { task: { "hits": {k: val}, "mrr": val } } }

    model_name is one of ALL_MODELS from config:
      cosine_scibert, cosine_pubmedbert,
      node2vec, metapath2vec, ephen,
      rgcn, rotate, transe, complex, graphsage,
      ensemble
    """
    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]

    # L2-normalise cosine embeddings once
    def norm_emb(e):
        return e / (np.linalg.norm(e, axis=1, keepdims=True) + 1e-9)

    sci_doi_n  = norm_emb(scibert_doi_emb)   if scibert_doi_emb   is not None else None
    sci_lbl_n  = norm_emb(scibert_label_emb) if scibert_label_emb is not None else None
    pub_doi_n  = norm_emb(pubmedbert_doi_emb)   if pubmedbert_doi_emb   is not None else None
    pub_lbl_n  = norm_emb(pubmedbert_label_emb) if pubmedbert_label_emb is not None else None

    all_model_names = [
        "cosine_scibert", "cosine_pubmedbert",
        "node2vec", "metapath2vec", "ephen",
        "rgcn", "rotate", "transe", "complex", "graphsage",
        "ensemble",
    ]
    results = {m: {} for m in all_model_names}

    for task, cfg in TASKS.items():
        # ── Resolve test/train data ───────────────────────────────────────────
        if test_rows_override and task in test_rows_override:
            test_df = test_rows_override[task]
        else:
            test_df = pd.read_csv(cfg["test"])

        if train_edges_override and task in train_edges_override:
            inv_node = {v: k for k, v in node_index.items()}
            train_rows = train_edges_override[task]
            train_counts = {}
            for h, t in train_rows:
                lbl = inv_node.get(t, "")
                train_counts[lbl] = train_counts.get(lbl, 0) + 1
            total_train = len(train_rows)
            all_labels  = sorted(
                set(test_df["neighbor"].unique()) |
                set(pd.read_csv(cfg["train"])["neighbor"].unique())
            )
        else:
            train_df     = pd.read_csv(cfg["train"])
            all_labels   = sorted(set(train_df["neighbor"]) | set(test_df["neighbor"]))
            train_counts = train_df["neighbor"].value_counts().to_dict()
            total_train  = len(train_df)

        cand_labels  = all_labels
        cand_gids    = [node_index.get(l) for l in cand_labels]
        cand_sci_ids = [label_idx.get(l) for l in cand_labels]
        r_id         = rel_index.get(task, 0)

        ranked_per_model = {m: [] for m in all_model_names}
        true_all = []

        for _, row in test_df.iterrows():
            doi  = row["node"]
            true = row["neighbor"]
            true_all.append(true)

            h_gid    = node_index.get(doi)
            h_sci_id = doi_idx.get(doi)   # index into scibert/pubmedbert emb arrays

            score_dict = {}

            # ── cosine_scibert ────────────────────────────────────────────────
            if sci_doi_n is not None and h_sci_id is not None:
                valid = [(i, s) for i, s in enumerate(cand_sci_ids) if s is not None]
                if valid:
                    idxs, sids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    cos = score_cosine(sci_doi_n, sci_lbl_n, h_sci_id, list(sids))
                    for pos, val in zip(idxs, cos): s[pos] = val
                    score_dict["cosine_scibert"] = s

            # ── cosine_pubmedbert ─────────────────────────────────────────────
            if pub_doi_n is not None and h_sci_id is not None:
                valid = [(i, s) for i, s in enumerate(cand_sci_ids) if s is not None]
                if valid:
                    idxs, sids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    cos = score_cosine(pub_doi_n, pub_lbl_n, h_sci_id, list(sids))
                    for pos, val in zip(idxs, cos): s[pos] = val
                    score_dict["cosine_pubmedbert"] = s

            # ── node2vec (structure-only, no rel_id) ──────────────────────────
            if node2vec_node is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    n2v = score_node2vec(node2vec_node, h_gid, np.array(gids))
                    for pos, val in zip(idxs, n2v): s[pos] = val
                    score_dict["node2vec"] = s

            # ── metapath2vec (structure-only) ─────────────────────────────────
            if metapath2vec_node is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    m2v = score_metapath2vec(metapath2vec_node, h_gid, np.array(gids))
                    for pos, val in zip(idxs, m2v): s[pos] = val
                    score_dict["metapath2vec"] = s

            # ── ephen (structure-only) ────────────────────────────────────────
            if ephen_node is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    ep = score_ephen(ephen_node, h_gid, np.array(gids))
                    for pos, val in zip(idxs, ep): s[pos] = val
                    score_dict["ephen"] = s

            # ── rotate (BERT-init) ────────────────────────────────────────────
            if rotate_ent is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    rot = score_rotate(rotate_ent, rotate_rel, h_gid, r_id, np.array(gids))
                    for pos, val in zip(idxs, rot): s[pos] = val
                    score_dict["rotate"] = s

            # ── rgcn (BERT-init) ──────────────────────────────────────────────
            if rgcn_node is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    rg = score_rgcn(rgcn_node, rgcn_rel, h_gid, r_id, np.array(gids))
                    for pos, val in zip(idxs, rg): s[pos] = val
                    score_dict["rgcn"] = s

            # ── transe (BERT-init) ────────────────────────────────────────────
            if transe_ent is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    tr = score_transe(transe_ent, transe_rel, h_gid, r_id, np.array(gids))
                    for pos, val in zip(idxs, tr): s[pos] = val
                    score_dict["transe"] = s

            # ── complex (BERT-init) ───────────────────────────────────────────
            if complex_ent is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    cx = score_complex(complex_ent, complex_rel, h_gid, r_id, np.array(gids))
                    for pos, val in zip(idxs, cx): s[pos] = val
                    score_dict["complex"] = s

            # ── graphsage (BERT-init) ─────────────────────────────────────────
            if graphsage_node is not None and h_gid is not None:
                valid = [(i, g) for i, g in enumerate(cand_gids) if g is not None]
                if valid:
                    idxs, gids = zip(*valid)
                    s = np.full(len(cand_labels), -999.0)
                    gs = score_graphsage(graphsage_node, graphsage_rel, h_gid, r_id, np.array(gids))
                    for pos, val in zip(idxs, gs): s[pos] = val
                    score_dict["graphsage"] = s

            # ── ensemble: BERT-graph models + best cosine ─────────────────────
            # Only fuses BERT-graph models and the best available cosine
            ensemble_sources = ["rgcn", "rotate", "transe", "complex", "graphsage"]
            # Add whichever cosine is available (prefer pubmedbert, fallback scibert)
            for cn in ["cosine_pubmedbert", "cosine_scibert"]:
                if cn in score_dict:
                    ensemble_sources.append(cn)
                    break

            ens_scores = [score_dict[m] for m in ensemble_sources if m in score_dict]
            if ens_scores:
                ens = np.zeros(len(cand_labels))
                for s in ens_scores:
                    valid_mask = s > -999.0
                    if valid_mask.any():
                        normed = np.zeros_like(s)
                        normed[valid_mask] = minmax_norm(s[valid_mask])
                        ens += normed
                score_dict["ensemble"] = ens / max(len(ens_scores), 1)

            # ── Rank with frequency calibration ──────────────────────────────
            for model_name in all_model_names:
                if model_name in score_dict:
                    ranked = calibrate(score_dict[model_name], cand_labels,
                                       train_counts, total_train)
                else:
                    ranked = cand_labels
                ranked_per_model[model_name].append(ranked)

        # ── Compute Hits@k and MRR for all k ─────────────────────────────────
        for model_name in all_model_names:
            results[model_name][task] = {
                "hits": {k: hits_at_k(ranked_per_model[model_name], true_all, k)
                         for k in EVAL_K_VALUES},
                "mrr":  mrr(ranked_per_model[model_name], true_all),
            }

    return results
