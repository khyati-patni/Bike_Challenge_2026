"""
stage3a_rgcn.py
────────────────
Relational Graph Convolutional Network (R-GCN) for link prediction.

Architecture:
  - Node features: encoder embeddings (768-d) projected → RGCN_HIDDEN
  - 2 R-GCN layers with per-relation weight matrices
  - Cross-task training: all 5 relation types simultaneously
  - Link prediction head: score(h,r,t) = h^T W_r t

Called by stage5_cv_experiment.py with a specific encoder and fold.

Usage (standalone):
  python stage3a_rgcn.py --encoder scibert --out-dir results/scibert
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (DATA_DIR, RES_DIR,
                    RGCN_HIDDEN, RGCN_OUT, RGCN_LAYERS,
                    RGCN_DROPOUT, RGCN_LR, RGCN_EPOCHS, RGCN_NEG_RATIO)

GRAPH_FILE    = DATA_DIR / "graph.json"
DOI_IDX_FILE  = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE= DATA_DIR / "label_index.json"


def build_adj(graph, n_nodes, device):
    import torch
    adjs = {}
    for task, edges in graph["train_edges"].items():
        if not edges:
            continue
        src = torch.tensor([e[0] for e in edges], dtype=torch.long)
        dst = torch.tensor([e[1] for e in edges], dtype=torch.long)
        src_all = torch.cat([src, dst])
        dst_all = torch.cat([dst, src])
        indices = torch.stack([src_all, dst_all]).to(device)
        deg     = torch.zeros(n_nodes).scatter_add(0, src_all, torch.ones(len(src_all)))
        vals    = (1.0 / deg.clamp(min=1))[src_all].to(device)
        adjs[task] = torch.sparse_coo_tensor(indices, vals, (n_nodes, n_nodes)).to(device)
    return adjs


class RGCN:
    def __init__(self, n_nodes, n_rels, in_dim, hidden, out_dim, dropout, device):
        import torch
        import torch.nn as nn
        self.torch  = torch
        self.device = device
        self.n_rels = n_rels

        self.proj     = nn.Linear(in_dim, hidden, bias=False).to(device)
        self.W1       = nn.Parameter(torch.empty(n_rels, hidden, hidden).to(device))
        self.W1_self  = nn.Parameter(torch.empty(hidden, hidden).to(device))
        self.W2       = nn.Parameter(torch.empty(n_rels, hidden, out_dim).to(device))
        self.W2_self  = nn.Parameter(torch.empty(hidden, out_dim).to(device))
        self.R_score  = nn.Parameter(torch.empty(n_rels, out_dim, out_dim).to(device))

        for p in [self.W1, self.W2, self.R_score]:
            nn.init.xavier_uniform_(p.view(-1, p.shape[-2], p.shape[-1])[0].unsqueeze(0))
        nn.init.xavier_uniform_(self.W1_self.unsqueeze(0))
        nn.init.xavier_uniform_(self.W2_self.unsqueeze(0))

        self.drop = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        params = (list(self.proj.parameters()) +
                  [self.W1, self.W1_self, self.W2, self.W2_self, self.R_score])
        self.opt = torch.optim.Adam(params, lr=RGCN_LR)

    def forward(self, x, adjs, rel_index):
        H = self.relu(self.proj(x))
        H = self.drop(H)
        agg = H @ self.W1_self
        for task, adj in adjs.items():
            r = rel_index[task]
            agg = agg + self.torch.sparse.mm(adj, H @ self.W1[r])
        H = self.relu(agg)
        H = self.drop(H)
        agg2 = H @ self.W2_self
        for task, adj in adjs.items():
            r = rel_index[task]
            agg2 = agg2 + self.torch.sparse.mm(adj, H @ self.W2[r])
        return self.relu(agg2)

    def train_step(self, x, adjs, all_pos, r_ids, n_nodes, rel_index):
        torch = self.torch
        self.opt.zero_grad()
        H = self.forward(x, adjs, rel_index)
        h_pos = torch.tensor([e[0] for e in all_pos], dtype=torch.long, device=self.device)
        t_pos = torch.tensor([e[1] for e in all_pos], dtype=torch.long, device=self.device)
        r_pos = torch.tensor(r_ids, dtype=torch.long, device=self.device)
        h_neg = h_pos.repeat(RGCN_NEG_RATIO)
        r_neg = r_pos.repeat(RGCN_NEG_RATIO)
        t_neg = torch.randint(0, n_nodes, (len(h_pos) * RGCN_NEG_RATIO,), device=self.device)

        def score(H, h, r, t):
            return torch.einsum('bi,bij,bj->b', H[h], self.R_score[r], H[t])

        pos_s = score(H, h_pos, r_pos, t_pos)
        neg_s = score(H, h_neg, r_neg, t_neg)
        loss = (-torch.log(torch.sigmoid(pos_s) + 1e-9).mean()
                -torch.log(1 - torch.sigmoid(neg_s) + 1e-9).mean())
        loss.backward()
        self.opt.step()
        return loss.item(), H.detach()

    def get_emb(self, x, adjs, rel_index):
        with self.torch.no_grad():
            return self.forward(x, adjs, rel_index).cpu().numpy()


def train_rgcn(enc_name: str, out_dir: pathlib.Path,
               train_edges_override: dict = None,
               verbose: bool = True):
    """
    Train R-GCN.  If train_edges_override is given (for CV folds),
    uses those edges instead of the graph file's train_edges.

    Returns (node_emb np.ndarray, rel_weights np.ndarray)
    """
    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if verbose:
        print(f"[R-GCN] encoder={enc_name}  device={device}")

    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]
    n_nodes    = graph["n_nodes"]
    n_rels     = graph["n_relations"]

    doi_emb_path   = DATA_DIR / f"{enc_name}_doi_embeddings.npy"
    label_emb_path = DATA_DIR / f"{enc_name}_label_embeddings.npy"
    doi_emb   = np.load(doi_emb_path)
    label_emb = np.load(label_emb_path)
    in_dim    = doi_emb.shape[1]  # 768

    x_np = np.zeros((n_nodes, in_dim), dtype=np.float32)
    for name, gid in node_index.items():
        if name in doi_idx:
            x_np[gid] = doi_emb[doi_idx[name]]
        elif name in label_idx:
            x_np[gid] = label_emb[label_idx[name]]
    x = torch.tensor(x_np, dtype=torch.float32, device=device)

    edges = train_edges_override if train_edges_override is not None else graph["train_edges"]
    adjs  = {}
    for task, edge_list in edges.items():
        if not edge_list:
            continue
        src = torch.tensor([e[0] for e in edge_list], dtype=torch.long)
        dst = torch.tensor([e[1] for e in edge_list], dtype=torch.long)
        src_all = torch.cat([src, dst])
        dst_all = torch.cat([dst, src])
        indices = torch.stack([src_all, dst_all]).to(device)
        deg  = torch.zeros(n_nodes).scatter_add(0, src_all, torch.ones(len(src_all)))
        vals = (1.0 / deg.clamp(min=1))[src_all].to(device)
        adjs[task] = torch.sparse_coo_tensor(indices, vals, (n_nodes, n_nodes)).to(device)

    all_pos, r_ids = [], []
    for task, edge_list in edges.items():
        r = rel_index[task]
        for e in edge_list:
            all_pos.append(e)
            r_ids.append(r)

    model = RGCN(n_nodes, n_rels, in_dim, RGCN_HIDDEN, RGCN_OUT,
                 RGCN_DROPOUT, device)

    for epoch in range(1, RGCN_EPOCHS + 1):
        loss, _ = model.train_step(x, adjs, all_pos, r_ids, n_nodes, rel_index)
        if verbose and (epoch % 100 == 0 or epoch == 1):
            print(f"  epoch {epoch:4d}/{RGCN_EPOCHS}  loss={loss:.4f}")

    node_emb   = model.get_emb(x, adjs, rel_index)
    rel_weights = model.R_score.detach().cpu().numpy()

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "rgcn_node_emb.npy", node_emb)
    np.save(out_dir / "rgcn_rel_weights.npy", rel_weights)
    if verbose:
        print(f"[R-GCN done] shape={node_emb.shape}")
    return node_emb, rel_weights


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", choices=["scibert", "pubmedbert"], default="scibert")
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_rgcn(args.encoder, args.out_dir, verbose=True)
