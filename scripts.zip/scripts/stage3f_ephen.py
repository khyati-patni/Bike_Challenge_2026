"""
stage3f_ephen.py — EPHEN spectral heat-kernel embedding.
Structure-only version: uses only KG topology (Laplacian eigenvectors).
Optionally concatenates text projections (controlled by EPHEN_TEXT_WEIGHT).
Matches the NatUKE EPHEN baseline.
"""
import argparse, json, pathlib, sys
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import DATA_DIR, RES_DIR, EPHEN_DIM, EPHEN_HEAT_T, EPHEN_K_EIGEN, EPHEN_NORM_EMB

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


def build_laplacian(graph, edges_override=None):
    edges = edges_override or graph["train_edges"]
    n = graph["n_nodes"]
    rows, cols = [], []
    for task_edges in edges.values():
        for h, t in task_edges:
            rows += [h, t]; cols += [t, h]
    if not rows:
        return sp.eye(n, format="csr")
    A = sp.coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n)).tocsr()
    A = (A + A.T); A.data = np.ones_like(A.data)
    deg = np.asarray(A.sum(1)).flatten()
    d_inv_sq = np.where(deg > 0, deg ** -0.5, 0.0)
    D = sp.diags(d_inv_sq)
    return (sp.eye(n, format="csr") - D @ A @ D).tocsr()


def train_ephen(enc_name, out_dir, train_edges_override=None, verbose=True):
    """
    enc_name is ignored — EPHEN is structure-only (spectral).
    Kept for interface compatibility.
    """
    graph   = json.loads(GRAPH_FILE.read_text())
    n_nodes = graph["n_nodes"]
    if verbose: print(f"[EPHEN] structure-only  n_nodes={n_nodes}")

    L = build_laplacian(graph, train_edges_override)
    k = min(EPHEN_K_EIGEN, n_nodes - 2)
    try:
        vals, vecs = spla.eigsh(L, k=k, which="SM", tol=1e-4, maxiter=3000)
    except Exception:
        if verbose: print("  [EPHEN] eigsh fallback → random")
        vecs = np.random.randn(n_nodes, k).astype(np.float32)
        vals = np.zeros(k, dtype=np.float32)

    heat = np.exp(-EPHEN_HEAT_T * np.maximum(vals, 0.0))
    spectral = (vecs * heat[np.newaxis, :]).astype(np.float32)   # (n, k)

    # Pad or trim to EPHEN_DIM
    if k < EPHEN_DIM:
        pad = np.zeros((n_nodes, EPHEN_DIM - k), dtype=np.float32)
        emb = np.concatenate([spectral, pad], axis=1)
    else:
        emb = spectral[:, :EPHEN_DIM]

    if EPHEN_NORM_EMB:
        norms = np.linalg.norm(emb, axis=1, keepdims=True) + 1e-9
        emb = emb / norms

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "ephen_node_emb.npy", emb)
    if verbose: print(f"[EPHEN done] shape={emb.shape}")
    return emb


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_ephen(None, args.out_dir, verbose=True)
