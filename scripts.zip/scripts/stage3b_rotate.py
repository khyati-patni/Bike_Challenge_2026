"""
stage3b_rotate.py
──────────────────
RotatE KG embedding: each relation is a rotation in complex space.
  score(h, r, t) = -||h ∘ r - t||

Initialised from encoder (SciBERT or PubMedBERT) projected phases.
All 5 relations trained jointly → cross-task transfer.

Usage (standalone):
  python stage3b_rotate.py --encoder scibert --out-dir results/scibert
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (DATA_DIR, RES_DIR,
                    ROTATE_DIM, ROTATE_LR, ROTATE_EPOCHS,
                    ROTATE_NEG, ROTATE_MARGIN, ROTATE_BATCH)

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


def scibert_to_phase(emb_np, dim, seed=42):
    np.random.seed(seed)
    proj = np.random.randn(emb_np.shape[1], dim).astype(np.float32) / np.sqrt(dim)
    out  = emb_np @ proj
    mn, mx = out.min(), out.max()
    return ((out - mn) / (mx - mn + 1e-9) * 2 * np.pi - np.pi).astype(np.float32)


def rotate_score_batch(ent, rel, h_ids, r_ids, t_ids, torch):
    h = ent[h_ids]; r = rel[r_ids]; t = ent[t_ids]
    re_h, im_h = torch.cos(h), torch.sin(h)
    re_r, im_r = torch.cos(r), torch.sin(r)
    re_t, im_t = torch.cos(t), torch.sin(t)
    re_rot = re_h * re_r - im_h * im_r
    im_rot = re_h * im_r + im_h * re_r
    dist = ((re_rot - re_t)**2 + (im_rot - im_t)**2 + 1e-9).sqrt().sum(-1)
    return -dist


def train_rotate(enc_name: str, out_dir: pathlib.Path,
                 train_edges_override: dict = None,
                 verbose: bool = True):
    """
    Train RotatE.  Returns (ent_emb, rel_emb).
    """
    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if verbose:
        print(f"[RotatE] encoder={enc_name}  device={device}")

    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]
    n_nodes    = graph["n_nodes"]
    n_rels     = graph["n_relations"]

    doi_emb   = np.load(DATA_DIR / f"{enc_name}_doi_embeddings.npy")
    label_emb = np.load(DATA_DIR / f"{enc_name}_label_embeddings.npy")

    sci_emb = np.zeros((n_nodes, doi_emb.shape[1]), dtype=np.float32)
    for name, gid in node_index.items():
        if name in doi_idx:
            sci_emb[gid] = doi_emb[doi_idx[name]]
        elif name in label_idx:
            sci_emb[gid] = label_emb[label_idx[name]]

    init_phases = scibert_to_phase(sci_emb, ROTATE_DIM)
    ent_phase = torch.nn.Parameter(torch.tensor(init_phases, device=device))
    rel_phase = torch.nn.Parameter(
        torch.zeros(n_rels, ROTATE_DIM, device=device).uniform_(-np.pi, np.pi))
    opt = torch.optim.Adam([ent_phase, rel_phase], lr=ROTATE_LR)

    edges = train_edges_override if train_edges_override is not None else graph["train_edges"]
    triples = []
    for task, edge_list in edges.items():
        r = rel_index[task]
        for e in edge_list:
            triples.append((e[0], r, e[1]))

    if not triples:
        print("[RotatE] no training triples — returning init phases")
        return init_phases, np.zeros((n_rels, ROTATE_DIM), dtype=np.float32)

    triples_t = torch.tensor(triples, dtype=torch.long, device=device)
    n_triples = len(triples)
    if verbose:
        print(f"[RotatE] triples={n_triples}  epochs={ROTATE_EPOCHS}  dim={ROTATE_DIM}")

    for epoch in range(1, ROTATE_EPOCHS + 1):
        idx    = torch.randperm(n_triples, device=device)
        t_shuf = triples_t[idx]
        ep_loss, n_batches = 0.0, 0

        for start in range(0, n_triples, ROTATE_BATCH):
            batch = t_shuf[start: start + ROTATE_BATCH]
            if len(batch) == 0:
                continue
            h_ids, r_ids, t_ids = batch[:, 0], batch[:, 1], batch[:, 2]
            neg_t = torch.randint(0, n_nodes, (len(batch), ROTATE_NEG), device=device)

            opt.zero_grad()
            pos_score = rotate_score_batch(ent_phase, rel_phase, h_ids, r_ids, t_ids, torch)
            h_exp = h_ids.unsqueeze(1).expand(-1, ROTATE_NEG).reshape(-1)
            r_exp = r_ids.unsqueeze(1).expand(-1, ROTATE_NEG).reshape(-1)
            neg_score = rotate_score_batch(
                ent_phase, rel_phase, h_exp, r_exp, neg_t.reshape(-1), torch
            ).reshape(len(batch), ROTATE_NEG)
            neg_w = torch.softmax(neg_score.detach(), dim=-1)
            pos_exp = pos_score.unsqueeze(1).expand_as(neg_score)
            loss = (neg_w * torch.clamp(ROTATE_MARGIN + neg_score - pos_exp, min=0)).sum(-1).mean()
            loss.backward()
            opt.step()
            ep_loss += loss.item()
            n_batches += 1

        if verbose and (epoch % 100 == 0 or epoch == 1):
            print(f"  epoch {epoch:4d}/{ROTATE_EPOCHS}  loss={ep_loss/max(n_batches,1):.4f}")

    ent_np = ent_phase.detach().cpu().numpy()
    rel_np = rel_phase.detach().cpu().numpy()

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "rotate_ent_emb.npy", ent_np)
    np.save(out_dir / "rotate_rel_emb.npy", rel_np)
    if verbose:
        print(f"[RotatE done] ent shape={ent_np.shape}")
    return ent_np, rel_np


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", choices=["scibert", "pubmedbert"], default="scibert")
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_rotate(args.encoder, args.out_dir, verbose=True)
