"""
stage1_encode_embeddings.py
────────────────────────────
Encodes DOI texts and label strings with BOTH SciBERT and PubMedBERT,
saving separate embedding files for each encoder.

This allows a direct, controlled comparison of:
  - allenai/scibert_scivocab_uncased       (general biomedical science)
  - microsoft/BiomedNLP-BiomedBERT-...     (PubMed-specific)

Outputs (for each encoder_name in {scibert, pubmedbert}):
  data/{encoder_name}_doi_embeddings.npy     shape (n_dois, 768)
  data/{encoder_name}_label_embeddings.npy   shape (n_labels, 768)
  data/doi_index.json                        {doi: row_index}
  data/label_index.json                      {label: row_index}
"""
import json, pathlib, sys
import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (TASKS, DATA_DIR, ENCODER_MODELS, BATCH_SIZE, MAX_SEQ_LEN)

DOI_TEXT_FILE  = DATA_DIR / "doi_texts.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


def load_encoder(model_id: str):
    from transformers import AutoTokenizer, AutoModel
    import torch
    print(f"  Loading encoder: {model_id}")
    tok   = AutoTokenizer.from_pretrained(model_id)
    model = AutoModel.from_pretrained(model_id)
    dev   = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(dev).eval()
    print(f"  Device: {dev}")
    return tok, model, dev


def mean_pool(output, mask):
    import torch
    h = output.last_hidden_state                      # (B, L, H)
    m = mask.unsqueeze(-1).float()
    return ((h * m).sum(1) / m.sum(1).clamp(1e-9)).cpu().numpy()


def encode_texts(texts: list, tok, model, dev) -> np.ndarray:
    import torch
    out = []
    for i in range(0, len(texts), BATCH_SIZE):
        batch = texts[i: i + BATCH_SIZE]
        enc   = tok(batch, padding=True, truncation=True,
                    max_length=MAX_SEQ_LEN, return_tensors="pt").to(dev)
        with torch.no_grad():
            vecs = mean_pool(model(**enc), enc["attention_mask"])
        out.append(vecs)
        print(f"    encoded {min(i + BATCH_SIZE, len(texts))}/{len(texts)}", end="\r")
    print()
    return np.vstack(out).astype(np.float32)


def collect_labels() -> list:
    labels = set()
    for cfg in TASKS.values():
        for split in ("train", "test"):
            labels.update(pd.read_csv(cfg[split])["neighbor"].unique())
    return sorted(labels)


def main():
    if not DOI_TEXT_FILE.exists():
        print("[!] data/doi_texts.json missing — run stage0_fetch_abstracts.py first")
        sys.exit(1)

    doi_texts = json.loads(DOI_TEXT_FILE.read_text())
    doi_list  = sorted(doi_texts.keys())
    doi_index = {d: i for i, d in enumerate(doi_list)}
    doi_raw   = [doi_texts[d].strip() or f"doi:{d}" for d in doi_list]

    label_list  = collect_labels()
    label_index = {l: i for i, l in enumerate(label_list)}

    # Save index files (shared across encoders)
    DOI_IDX_FILE.write_text(json.dumps(doi_index, indent=2))
    LABEL_IDX_FILE.write_text(json.dumps(label_index, indent=2))
    print(f"[stage1] {len(doi_list)} DOIs, {len(label_list)} unique labels")

    for enc_name, model_id in ENCODER_MODELS.items():
        doi_emb_path   = DATA_DIR / f"{enc_name}_doi_embeddings.npy"
        label_emb_path = DATA_DIR / f"{enc_name}_label_embeddings.npy"

        if doi_emb_path.exists() and label_emb_path.exists():
            print(f"\n[skip] {enc_name} embeddings already exist")
            continue

        print(f"\n{'='*60}")
        print(f"  Encoding with {enc_name.upper()}")
        print(f"{'='*60}")
        tok, model, dev = load_encoder(model_id)

        print(f"  Encoding {len(doi_list)} DOIs ...")
        doi_emb = encode_texts(doi_raw, tok, model, dev)
        np.save(doi_emb_path, doi_emb)
        print(f"  Saved {doi_emb_path.name}  shape={doi_emb.shape}")

        print(f"  Encoding {len(label_list)} labels ...")
        label_emb = encode_texts(label_list, tok, model, dev)
        np.save(label_emb_path, label_emb)
        print(f"  Saved {label_emb_path.name}  shape={label_emb.shape}")

        # Free GPU memory
        del model, tok
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass

    print(f"\n[stage1 done] embeddings for: {list(ENCODER_MODELS.keys())}")


if __name__ == "__main__":
    main()
