"""
stage3h_complex.py
───────────────────
ComplEx — Complex Embeddings for Simple Link Prediction
(Trouillon et al., ICML 2016).

ComplEx operates in complex (ℂ) space:
  score(h, r, t) = Re(<e_h, w_r, ē_t>)
                 = Re(∑ [e_h ⊙ w_r ⊙ conj(e_t)])

where e_h, w_r, e_t ∈ ℂ^d are complex vectors, and ē_t is the
complex conjugate of e_t.

In real notation with dim=D (embedding of size 2D: real + imag):
  score = (re_h ⊙ re_r + im_h ⊙ im_r) · re_t
        + (re_h ⊙ im_r - im_h ⊙ re_r) · im_t

This naturally handles asymmetric relations (unlike DistMult) and
antisymmetric, symmetric, and inverse patterns simultaneously.

Initialised from encoder text projections.
Trained with binary cross-entropy + L2 regularisation.

Usage (standalone):
  python stage3h_complex.py --encoder scibert --out-dir results/scibert
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (DATA_DIR, RES_DIR)

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"

# ── ComplEx hyperparameters ───────────────────────────────────────────────────
COMPLEX_DIM    = 256    # complex dim d → real representation is 2d
COMPLEX_LR     = 1e-3
COMPLEX_EPOCHS = 400
COMPLEX_NEG    = 64
COMPLEX_BATCH  = 256
COMPLEX_REG    = 1e-3   # L2 regularisation weight


def complex_score_np(re_h, im_h, re_r, im_r, re_t, im_t):
    """ComplEx score in numpy: Re(<h, r, conj(t)>). Returns scalar."""
    return (
        np.dot(re_h * re_r + im_h * im_r, re_t) +
        np.dot(re_h * im_r - im_h * re_r, im_t)
    )


def train_complex(enc_name: str, out_dir: pathlib.Path,
                  train_edges_override: dict = None,
                  verbose: bool = True):
    """
    Train ComplEx.
    Returns (ent_emb np.ndarray (n_nodes, 2*COMPLEX_DIM),  [re|im]
             rel_emb np.ndarray (n_rels,  2*COMPLEX_DIM))  [re|im]
    """
    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if verbose:
        print(f"[ComplEx] encoder={enc_name}  device={device}  dim={COMPLEX_DIM}")

    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]
    n_nodes    = graph["n_nodes"]
    n_rels     = graph["n_relations"]

    doi_emb   = np.load(DATA_DIR / f"{enc_name}_doi_embeddings.npy")
    label_emb = np.load(DATA_DIR / f"{enc_name}_label_embeddings.npy")
    in_dim    = doi_emb.shape[1]   # 768

    # Build full node feature matrix
    full_emb = np.zeros((n_nodes, in_dim), dtype=np.float32)
    for name, gid in node_index.items():
        if name in doi_idx:
            full_emb[gid] = doi_emb[doi_idx[name]]
        elif name in label_idx:
            full_emb[gid] = label_emb[label_idx[name]]

    # Project to 2*COMPLEX_DIM: first half = real part, second = imag part
    np.random.seed(42)
    proj = np.random.randn(in_dim, 2 * COMPLEX_DIM).astype(np.float32) / np.sqrt(in_dim)
    init_ent = full_emb @ proj   # (n_nodes, 2*COMPLEX_DIM)
    # Scale to unit sphere
    norms = np.linalg.norm(init_ent, axis=1, keepdims=True) + 1e-9
    init_ent = init_ent / norms

    # Parameters: entity and relation complex embeddings (stored as [re|im])
    ent_emb = torch.nn.Parameter(torch.tensor(init_ent, device=device))
    rel_emb = torch.nn.Parameter(
        torch.empty(n_rels, 2 * COMPLEX_DIM, device=device).uniform_(-0.1, 0.1))
    opt = torch.optim.Adagrad([ent_emb, rel_emb], lr=COMPLEX_LR,
                               weight_decay=COMPLEX_REG)

    edges = train_edges_override if train_edges_override is not None else graph["train_edges"]
    triples = []
    for task, edge_list in edges.items():
        r = rel_index[task]
        for e in edge_list:
            triples.append((e[0], r, e[1]))

    if not triples:
        return init_ent, np.zeros((n_rels, 2 * COMPLEX_DIM), dtype=np.float32)

    triples_t = torch.tensor(triples, dtype=torch.long, device=device)
    n_triples  = len(triples)
    if verbose:
        print(f"[ComplEx] triples={n_triples}  epochs={COMPLEX_EPOCHS}")

    for epoch in range(1, COMPLEX_EPOCHS + 1):
        idx    = torch.randperm(n_triples, device=device)
        t_shuf = triples_t[idx]
        ep_loss, n_batches = 0.0, 0

        for start in range(0, n_triples, COMPLEX_BATCH):
            batch = t_shuf[start: start + COMPLEX_BATCH]
            if len(batch) == 0:
                continue
            h_ids, r_ids, t_ids = batch[:, 0], batch[:, 1], batch[:, 2]
            neg_t = torch.randint(0, n_nodes,
                                  (len(batch) * COMPLEX_NEG,), device=device)
            opt.zero_grad()

            D = COMPLEX_DIM
            # Split into real and imaginary parts
            re_h = ent_emb[h_ids, :D];       im_h = ent_emb[h_ids, D:]
            re_r = rel_emb[r_ids, :D];       im_r = rel_emb[r_ids, D:]
            re_tp = ent_emb[t_ids, :D];      im_tp = ent_emb[t_ids, D:]

            # ComplEx score: Re(<h, r, conj(t)>)
            pos_score = (
                (re_h * re_r * re_tp).sum(-1) +
                (im_h * im_r * re_tp).sum(-1) +
                (re_h * im_r * im_tp).sum(-1) -
                (im_h * re_r * im_tp).sum(-1)
            )   # (B,)

            h_exp = h_ids.repeat(COMPLEX_NEG)
            r_exp = r_ids.repeat(COMPLEX_NEG)
            re_hn = ent_emb[h_exp, :D]; im_hn = ent_emb[h_exp, D:]
            re_rn = rel_emb[r_exp, :D]; im_rn = rel_emb[r_exp, D:]
            re_tn = ent_emb[neg_t, :D]; im_tn = ent_emb[neg_t, D:]

            neg_score = (
                (re_hn * re_rn * re_tn).sum(-1) +
                (im_hn * im_rn * re_tn).sum(-1) +
                (re_hn * im_rn * im_tn).sum(-1) -
                (im_hn * re_rn * im_tn).sum(-1)
            ).reshape(len(batch), COMPLEX_NEG)   # (B, NEG)

            # Softplus BCE loss (smooth approximation)
            pos_loss = torch.nn.functional.softplus(-pos_score).mean()
            neg_loss = torch.nn.functional.softplus(neg_score).mean()
            loss = pos_loss + neg_loss
            loss.backward()
            opt.step()
            ep_loss += loss.item()
            n_batches += 1

        if verbose and (epoch % 100 == 0 or epoch == 1):
            print(f"  epoch {epoch:4d}/{COMPLEX_EPOCHS}  loss={ep_loss/max(n_batches,1):.4f}")

    ent_np = ent_emb.detach().cpu().numpy()
    rel_np = rel_emb.detach().cpu().numpy()

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "complex_ent_emb.npy", ent_np)
    np.save(out_dir / "complex_rel_emb.npy", rel_np)
    if verbose:
        print(f"[ComplEx done] ent shape={ent_np.shape}")
    return ent_np, rel_np


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", choices=["scibert", "pubmedbert"], default="scibert")
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_complex(args.encoder, args.out_dir, verbose=True)
