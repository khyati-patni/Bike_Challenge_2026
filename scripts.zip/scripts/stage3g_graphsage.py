"""
stage3g_graphsage.py
─────────────────────
GraphSAGE — Graph Sample and Aggregate (Hamilton et al., NeurIPS 2017).

GraphSAGE is the 4th graph embedding method added alongside Node2Vec,
Metapath2Vec, and EPHEN.  It is one of the strongest inductive GNN
baselines, consistently outperforming DeepWalk/Node2Vec on heterogeneous
biomedical graphs.

Architecture:
  - Inductive: aggregates sampled neighbourhood features → no need to
    retrain when new nodes appear
  - 2-layer mean aggregator:
      h_v^{(l+1)} = σ(W · CONCAT(h_v^{(l)}, MEAN_{u ∈ N(v)} h_u^{(l)}))
  - Initialised from encoder (SciBERT / PubMedBERT) text features
  - Multi-relation: separate per-relation weight matrix W_r for link scoring
    (same as R-GCN but with neighbourhood sampling and mean aggregation)

Training loss: margin-based link prediction (same as TransE/RotatE)
  L = Σ max(0, γ - score_pos + score_neg)

Scoring at eval:
  score(h, r, t) = h_emb^T W_r t_emb

Usage (standalone):
  python stage3g_graphsage.py --encoder scibert --out-dir results/scibert
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (DATA_DIR, RES_DIR)

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"

# ── GraphSAGE hyperparameters ──────────────────────────────────────────────────
SAGE_HIDDEN   = 256
SAGE_OUT      = 256
SAGE_LAYERS   = 2
SAGE_DROPOUT  = 0.2
SAGE_LR       = 1e-3
SAGE_EPOCHS   = 300
SAGE_NEG      = 5        # negative samples per positive
SAGE_MARGIN   = 2.0      # margin for ranking loss
SAGE_SAMPLE_K = 15       # neighbourhood sample size per node


def build_adj_list(graph: dict, train_edges_override: dict = None) -> dict:
    """Build adjacency list (undirected, all relations merged)."""
    edges  = train_edges_override if train_edges_override is not None else graph["train_edges"]
    n      = graph["n_nodes"]
    adj    = {i: [] for i in range(n)}
    for task_edges in edges.values():
        for h, t in task_edges:
            adj[h].append(t)
            adj[t].append(h)
    for node in adj:
        adj[node] = list(set(adj[node]))
    return adj


class GraphSAGEModel:
    """Pure-PyTorch 2-layer GraphSAGE with mean aggregation."""

    def __init__(self, n_nodes, n_rels, in_dim, hidden, out_dim, dropout, device):
        import torch
        import torch.nn as nn
        self.torch  = torch
        self.device = device
        self.n_rels = n_rels
        self.hidden = hidden
        self.out_dim = out_dim

        # Layer 1: projects concat(self, mean_nbr) → hidden
        # Input dim = in_dim (self) + in_dim (mean nbr) = 2*in_dim
        self.W1 = nn.Linear(2 * in_dim, hidden, bias=True).to(device)
        # Layer 2: concat(hidden, mean_nbr_hidden) → out_dim
        self.W2 = nn.Linear(2 * hidden, out_dim, bias=True).to(device)

        # Per-relation scoring matrices
        self.R_score = nn.Parameter(
            torch.empty(n_rels, out_dim, out_dim).to(device))
        nn.init.xavier_uniform_(self.R_score.view(n_rels, out_dim, out_dim)[0].unsqueeze(0))
        for r in range(n_rels):
            nn.init.xavier_uniform_(self.R_score[r])

        self.drop  = nn.Dropout(dropout)
        self.relu  = nn.ReLU()

        params = (list(self.W1.parameters()) +
                  list(self.W2.parameters()) +
                  [self.R_score])
        self.opt = torch.optim.Adam(params, lr=SAGE_LR)

    def mean_agg(self, x: "torch.Tensor", adj: dict, sample_k: int,
                 rng: np.random.Generator) -> "torch.Tensor":
        """
        Compute sampled neighbourhood mean for all nodes.
        Returns tensor (n_nodes, x.shape[1]).
        """
        torch  = self.torch
        n      = x.shape[0]
        agg    = torch.zeros_like(x)

        for node in range(n):
            nbrs = adj[node]
            if not nbrs:
                agg[node] = x[node]
                continue
            if len(nbrs) > sample_k:
                sampled = rng.choice(nbrs, size=sample_k, replace=False).tolist()
            else:
                sampled = nbrs
            agg[node] = x[torch.tensor(sampled, dtype=torch.long, device=self.device)].mean(0)

        return agg

    def forward(self, x: "torch.Tensor", adj: dict, sample_k: int,
                rng: np.random.Generator) -> "torch.Tensor":
        # Layer 1
        mean1 = self.mean_agg(x, adj, sample_k, rng)
        h1    = self.relu(self.W1(self.torch.cat([x, mean1], dim=1)))
        h1    = self.drop(h1)
        # L2 normalise (as in the original GraphSAGE paper)
        h1    = h1 / (h1.norm(dim=1, keepdim=True).clamp(min=1e-9))

        # Layer 2
        mean2 = self.mean_agg(h1, adj, sample_k, rng)
        h2    = self.relu(self.W2(self.torch.cat([h1, mean2], dim=1)))
        h2    = self.drop(h2)
        h2    = h2 / (h2.norm(dim=1, keepdim=True).clamp(min=1e-9))
        return h2

    def score(self, H: "torch.Tensor", h_ids, r_ids, t_ids):
        torch = self.torch
        h = H[h_ids]
        t = H[t_ids]
        R = self.R_score[r_ids]
        return torch.einsum("bi,bij,bj->b", h, R, t)

    def train_step(self, x, adj, sample_k, rng, all_pos, r_ids_np, n_nodes):
        torch = self.torch
        self.opt.zero_grad()
        H = self.forward(x, adj, sample_k, rng)

        h_pos = torch.tensor([e[0] for e in all_pos], dtype=torch.long, device=self.device)
        t_pos = torch.tensor([e[1] for e in all_pos], dtype=torch.long, device=self.device)
        r_pos = torch.tensor(r_ids_np, dtype=torch.long, device=self.device)

        h_neg = h_pos.repeat(SAGE_NEG)
        r_neg = r_pos.repeat(SAGE_NEG)
        t_neg = torch.randint(0, n_nodes, (len(h_pos) * SAGE_NEG,), device=self.device)

        pos_s = self.score(H, h_pos, r_pos, t_pos)
        neg_s = self.score(H, h_neg, r_neg, t_neg)

        # Max-margin loss (averaged)
        neg_s_reshaped = neg_s.view(len(h_pos), SAGE_NEG)
        loss = torch.clamp(SAGE_MARGIN - pos_s.unsqueeze(1) + neg_s_reshaped, min=0.0).mean()
        loss.backward()
        self.opt.step()
        return loss.item(), H.detach()

    def get_emb(self, x, adj, sample_k):
        rng = np.random.default_rng(99)  # deterministic for eval
        with self.torch.no_grad():
            return self.forward(x, adj, sample_k, rng).cpu().numpy()


def train_graphsage(enc_name: str, out_dir: pathlib.Path,
                    train_edges_override: dict = None,
                    verbose: bool = True):
    """
    Train GraphSAGE.
    Returns (node_emb np.ndarray (n_nodes, SAGE_OUT),
             rel_weights np.ndarray (n_rels, SAGE_OUT, SAGE_OUT))
    """
    import torch
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if verbose:
        print(f"[GraphSAGE] encoder={enc_name}  device={device}")

    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]
    n_nodes    = graph["n_nodes"]
    n_rels     = graph["n_relations"]

    doi_emb   = np.load(DATA_DIR / f"{enc_name}_doi_embeddings.npy")
    label_emb = np.load(DATA_DIR / f"{enc_name}_label_embeddings.npy")
    in_dim    = doi_emb.shape[1]  # 768

    # Build node feature matrix from encoder embeddings
    x_np = np.zeros((n_nodes, in_dim), dtype=np.float32)
    for name, gid in node_index.items():
        if name in doi_idx:
            x_np[gid] = doi_emb[doi_idx[name]]
        elif name in label_idx:
            x_np[gid] = label_emb[label_idx[name]]
    x = torch.tensor(x_np, dtype=torch.float32, device=device)

    edges = train_edges_override if train_edges_override is not None else graph["train_edges"]
    adj   = build_adj_list(graph, train_edges_override)

    all_pos, r_ids_np = [], []
    for task, edge_list in edges.items():
        r = rel_index[task]
        for e in edge_list:
            all_pos.append(e)
            r_ids_np.append(r)
    r_ids_np = np.array(r_ids_np, dtype=np.int64)

    model = GraphSAGEModel(n_nodes, n_rels, in_dim, SAGE_HIDDEN, SAGE_OUT,
                            SAGE_DROPOUT, device)

    rng = np.random.default_rng(42)
    for epoch in range(1, SAGE_EPOCHS + 1):
        loss, _ = model.train_step(x, adj, SAGE_SAMPLE_K, rng, all_pos, r_ids_np, n_nodes)
        if verbose and (epoch % 100 == 0 or epoch == 1):
            print(f"  epoch {epoch:4d}/{SAGE_EPOCHS}  loss={loss:.4f}")

    node_emb    = model.get_emb(x, adj, SAGE_SAMPLE_K)
    rel_weights = model.R_score.detach().cpu().numpy()

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "graphsage_node_emb.npy",    node_emb)
    np.save(out_dir / "graphsage_rel_weights.npy", rel_weights)

    if verbose:
        print(f"[GraphSAGE done] shape={node_emb.shape}")
    return node_emb, rel_weights


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", choices=["scibert", "pubmedbert"], default="scibert")
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_graphsage(args.encoder, args.out_dir, verbose=True)
