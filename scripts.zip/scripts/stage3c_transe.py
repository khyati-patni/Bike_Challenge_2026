"""
stage3c_transe.py
──────────────────
TransE KG embedding: translational embedding model.
  score(h, r, t) = -||h + r - t||_p

Serves as an additional KG completion baseline.
Trained jointly across all 5 relations.

Usage (standalone):
  python stage3c_transe.py --encoder scibert --out-dir results/scibert
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (DATA_DIR, RES_DIR,
                    TRANSE_DIM, TRANSE_LR, TRANSE_EPOCHS,
                    TRANSE_NEG, TRANSE_MARGIN, TRANSE_BATCH, TRANSE_NORM)

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


def train_transe(enc_name: str, out_dir: pathlib.Path,
                 train_edges_override: dict = None,
                 verbose: bool = True):
    """
    Train TransE.  Returns (ent_emb, rel_emb).
    """
    import torch
    import torch.nn.functional as F
    device = "cuda" if torch.cuda.is_available() else "cpu"
    if verbose:
        print(f"[TransE] encoder={enc_name}  device={device}")

    graph      = json.loads(GRAPH_FILE.read_text())
    doi_idx    = json.loads(DOI_IDX_FILE.read_text())
    label_idx  = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    rel_index  = graph["rel_index"]
    n_nodes    = graph["n_nodes"]
    n_rels     = graph["n_relations"]

    doi_emb   = np.load(DATA_DIR / f"{enc_name}_doi_embeddings.npy")
    label_emb = np.load(DATA_DIR / f"{enc_name}_label_embeddings.npy")

    # Initialise entity embeddings from encoder projections
    np.random.seed(42)
    proj = np.random.randn(doi_emb.shape[1], TRANSE_DIM).astype(np.float32) / np.sqrt(TRANSE_DIM)
    full_emb = np.zeros((n_nodes, doi_emb.shape[1]), dtype=np.float32)
    for name, gid in node_index.items():
        if name in doi_idx:
            full_emb[gid] = doi_emb[doi_idx[name]]
        elif name in label_idx:
            full_emb[gid] = label_emb[label_idx[name]]

    init_ent = (full_emb @ proj).astype(np.float32)
    # L2-normalise entity init
    norms = np.linalg.norm(init_ent, axis=1, keepdims=True) + 1e-9
    init_ent = init_ent / norms

    ent_emb = torch.nn.Parameter(torch.tensor(init_ent, device=device))
    rel_emb = torch.nn.Parameter(
        torch.empty(n_rels, TRANSE_DIM, device=device).uniform_(-0.1, 0.1))
    opt = torch.optim.Adam([ent_emb, rel_emb], lr=TRANSE_LR)

    edges = train_edges_override if train_edges_override is not None else graph["train_edges"]
    triples = []
    for task, edge_list in edges.items():
        r = rel_index[task]
        for e in edge_list:
            triples.append((e[0], r, e[1]))

    if not triples:
        return init_ent, np.zeros((n_rels, TRANSE_DIM), dtype=np.float32)

    triples_t = torch.tensor(triples, dtype=torch.long, device=device)
    n_triples = len(triples)
    if verbose:
        print(f"[TransE] triples={n_triples}  epochs={TRANSE_EPOCHS}  dim={TRANSE_DIM}")

    for epoch in range(1, TRANSE_EPOCHS + 1):
        idx    = torch.randperm(n_triples, device=device)
        t_shuf = triples_t[idx]
        ep_loss, n_batches = 0.0, 0

        for start in range(0, n_triples, TRANSE_BATCH):
            batch = t_shuf[start: start + TRANSE_BATCH]
            if len(batch) == 0:
                continue
            h_ids, r_ids, t_ids = batch[:, 0], batch[:, 1], batch[:, 2]

            # Corrupt tail for negatives
            neg_t = torch.randint(0, n_nodes, (len(batch) * TRANSE_NEG,), device=device)

            opt.zero_grad()

            # Normalise entity embeddings (TransE constraint)
            with torch.no_grad():
                norms = ent_emb.norm(dim=1, keepdim=True).clamp(min=1.0)
                ent_emb.data = ent_emb.data / norms

            h = ent_emb[h_ids]; r = rel_emb[r_ids]; t_pos = ent_emb[t_ids]
            pos_score = -(h + r - t_pos).norm(dim=1, p=TRANSE_NORM)  # higher = better

            h_exp = h_ids.repeat(TRANSE_NEG)
            r_exp = r_ids.repeat(TRANSE_NEG)
            h_n = ent_emb[h_exp]; r_n = rel_emb[r_exp]; t_n = ent_emb[neg_t]
            neg_score = -(h_n + r_n - t_n).norm(dim=1, p=TRANSE_NORM)
            neg_score = neg_score.reshape(len(batch), TRANSE_NEG)

            pos_exp = pos_score.unsqueeze(1).expand_as(neg_score)
            loss = F.relu(TRANSE_MARGIN - pos_exp + neg_score).mean()
            loss.backward()
            opt.step()
            ep_loss += loss.item()
            n_batches += 1

        if verbose and (epoch % 100 == 0 or epoch == 1):
            print(f"  epoch {epoch:4d}/{TRANSE_EPOCHS}  loss={ep_loss/max(n_batches,1):.4f}")

    ent_np = ent_emb.detach().cpu().numpy()
    rel_np = rel_emb.detach().cpu().numpy()

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "transe_ent_emb.npy", ent_np)
    np.save(out_dir / "transe_rel_emb.npy", rel_np)
    if verbose:
        print(f"[TransE done] ent shape={ent_np.shape}")
    return ent_np, rel_np


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--encoder", choices=["scibert", "pubmedbert"], default="scibert")
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_transe(args.encoder, args.out_dir, verbose=True)
