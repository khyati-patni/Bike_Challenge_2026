"""
stage3e_metapath2vec.py — Structure-only Metapath2Vec (no BERT features).
Matches the original NatUKE Metapath2Vec baseline exactly.
Walks along typed metapaths: DOI→Label→DOI and Label→DOI→Label.
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import DATA_DIR, RES_DIR, M2V_DIM, M2V_WALK_LEN, M2V_NUM_WALKS
from config import M2V_WINDOW, M2V_EPOCHS, M2V_WORKERS, M2V_MIN_COUNT, M2V_NEG_SAMPLE

GRAPH_FILE     = DATA_DIR / "graph.json"
DOI_IDX_FILE   = DATA_DIR / "doi_index.json"
LABEL_IDX_FILE = DATA_DIR / "label_index.json"


def build_typed_adj(graph, train_edges_override=None):
    doi_idx   = json.loads(DOI_IDX_FILE.read_text())
    label_idx = json.loads(LABEL_IDX_FILE.read_text())
    node_index = graph["node_index"]
    doi_nodes   = {gid for name, gid in node_index.items() if name in doi_idx}
    label_nodes = {gid for name, gid in node_index.items() if name in label_idx}

    edges = train_edges_override or graph["train_edges"]
    d2l = {n: [] for n in doi_nodes}
    l2d = {n: [] for n in label_nodes}
    for task_edges in edges.values():
        for h, t in task_edges:
            if h in doi_nodes and t in label_nodes:
                d2l[h].append(t); l2d[t].append(h)
            elif h in label_nodes and t in doi_nodes:
                l2d[h].append(t); d2l[t].append(h)
    for n in d2l: d2l[n] = list(set(d2l[n]))
    for n in l2d: l2d[n] = list(set(l2d[n]))
    return d2l, l2d, doi_nodes, label_nodes


def metapath_walk(start_adj, next_adj, start, walk_len, rng):
    w = [start]; is_first = True
    for _ in range(walk_len - 1):
        cur = w[-1]
        nbrs = (start_adj if is_first else next_adj).get(cur, [])
        if not nbrs: break
        w.append(rng.choice(nbrs)); is_first = not is_first
    return w


def train_metapath2vec(enc_name, out_dir, train_edges_override=None, verbose=True):
    """enc_name ignored — structure-only."""
    from gensim.models import Word2Vec
    graph   = json.loads(GRAPH_FILE.read_text())
    n_nodes = graph["n_nodes"]
    if verbose: print(f"[Metapath2Vec] structure-only  n_nodes={n_nodes}")

    d2l, l2d, doi_nodes, label_nodes = build_typed_adj(graph, train_edges_override)
    rng = np.random.default_rng(42)
    walks = []
    for _ in range(M2V_NUM_WALKS):
        for s in rng.permutation(list(doi_nodes)):
            w = metapath_walk(d2l, l2d, int(s), M2V_WALK_LEN, rng)
            if len(w) > 1: walks.append(w)
        for s in rng.permutation(list(label_nodes)):
            w = metapath_walk(l2d, d2l, int(s), M2V_WALK_LEN, rng)
            if len(w) > 1: walks.append(w)

    str_walks = [[str(n) for n in w] for w in walks]
    model = Word2Vec(sentences=str_walks, vector_size=M2V_DIM, window=M2V_WINDOW,
                     min_count=M2V_MIN_COUNT, sg=1, hs=0, negative=M2V_NEG_SAMPLE,
                     workers=M2V_WORKERS, epochs=M2V_EPOCHS, seed=42)

    emb = np.zeros((n_nodes, M2V_DIM), dtype=np.float32)
    for i in range(n_nodes):
        key = str(i)
        if key in model.wv: emb[i] = model.wv[key]
        else: emb[i] = np.random.randn(M2V_DIM).astype(np.float32) * 0.01

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "metapath2vec_node_emb.npy", emb)
    if verbose: print(f"[Metapath2Vec done] shape={emb.shape}")
    return emb


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_metapath2vec(None, args.out_dir, verbose=True)
