#!/bin/bash

echo "Running Stage 1..."
python stage1_encode_embeddings.py

echo "Running Stage 2..."
python stage2_build_graph.py

echo "Running Stage 3 models..."
python stage3a_rgcn.py
python stage3b_rotate.py
python stage3c_transe.py
python stage3d_node2vec.py
python stage3e_metapath2vec.py
python stage3f_ephen.py
python stage3g_graphsage.py
python stage3h_complex.py

echo "Running Stage 4..."
python stage4_evaluate.py

echo "Running Stage 5..."
python stage5_cv_experiment.py
python stage5_natuke_stages.py

echo "Running Stage 6..."
python stage6_significance_test.py

echo "All stages completed!"    
