"""
config.py — BiKE v2
Single source of truth for all settings.

ARCHITECTURE CLARITY:
=====================
Two separate concerns:

1. TEXT ENCODERS (SciBERT, PubMedBERT):
   - Used ONLY for:
     a) Cosine similarity baselines (standalone Hits@K — no graph at all)
     b) Initialising BERT-based graph models (R-GCN, RotatE, TransE, ComplEx, GraphSAGE)
   - Each encoder produces a separate cosine score entry in the results table

2. GRAPH EMBEDDING MODELS (one result column each in the final table):
   Structure-only (no BERT features — pure graph structure, matching NatUKE):
     - Node2Vec
     - Metapath2Vec
     - EPHEN
   BERT-initialised (use SciBERT features as node feature init):
     - R-GCN
     - RotatE
     - TransE
     - ComplEx
     - GraphSAGE

FINAL TABLE (NatUKE format):
  Rows: C (name), B (bioActivity), S (specie), L (site), T (type)
  Cols: 1st, 2nd, 3rd, 4th stage
  One sub-table per model:
    SciBERT-cosine | PubMedBERT-cosine |
    Node2Vec | Metapath2Vec | EPHEN |
    R-GCN | RotatE | TransE | ComplEx | GraphSAGE |
    Ensemble

EVALUATION PROTOCOL (NatUKE 4-stage):
  1st: 20% train / 80% test
  2nd: 40% train / 60% test
  3rd: 60% train / 40% test
  4th: 80% train / 20% test
  Hits@k for k in {1, 5, 20, 50}
"""
import pathlib

ROOT     = pathlib.Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RES_DIR  = ROOT / "results"
RES_DIR.mkdir(exist_ok=True)

# ── NatUKE 4-stage evaluation design ─────────────────────────────────────────
STAGES      = [(0.20, 0.80), (0.40, 0.60), (0.60, 0.40), (0.80, 0.20)]
STAGE_NAMES = ["1st", "2nd", "3rd", "4th"]

# ── Hits@K values (NatUKE BiKE challenge: 1, 5, 20, 50) ──────────────────────
EVAL_K_VALUES = [1, 5, 20, 50]

# ── Task definitions ──────────────────────────────────────────────────────────
TASKS = {
    "bioActivity": {
        "train": DATA_DIR / "train_doi_bioActivity_5_3rd.csv",
        "test":  DATA_DIR / "test_doi_bioActivity_5_3rd.csv",
        "primary_k": 5,
        "short": "B",
    },
    "collectionSite": {
        "train": DATA_DIR / "train_doi_collectionSite_1_3rd.csv",
        "test":  DATA_DIR / "test_doi_collectionSite_1_3rd.csv",
        "primary_k": 20,
        "short": "L",
    },
    "collectionSpecie": {
        "train": DATA_DIR / "train_doi_collectionSpecie_5_3rd.csv",
        "test":  DATA_DIR / "test_doi_collectionSpecie_5_3rd.csv",
        "primary_k": 50,
        "short": "S",
    },
    "collectionType": {
        "train": DATA_DIR / "train_doi_collectionType_3_3rd.csv",
        "test":  DATA_DIR / "test_doi_collectionType_3_3rd.csv",
        "primary_k": 1,
        "short": "T",
    },
    "name": {
        "train": DATA_DIR / "train_doi_name_5_3rd.csv",
        "test":  DATA_DIR / "test_doi_name_5_3rd.csv",
        "primary_k": 50,
        "short": "C",
    },
}

# ── NatUKE reference table (from template — per method per stage) ─────────────
# Values indexed [1st, 2nd, 3rd, 4th]
NATUKE_TABLE = {
    "DeepWalk": {
        "name":             [0.08, 0.00, 0.00, 0.00],
        "bioActivity":      [0.41, 0.12, 0.10, 0.07],
        "collectionSpecie": [0.37, 0.24, 0.27, 0.25],
        "collectionSite":   [0.56, 0.41, 0.38, 0.29],
        "collectionType":   [0.25, 0.14, 0.14, 0.09],
    },
    "Node2Vec": {
        "name":             [0.08, 0.00, 0.00, 0.00],
        "bioActivity":      [0.41, 0.07, 0.03, 0.03],
        "collectionSpecie": [0.36, 0.22, 0.25, 0.24],
        "collectionSite":   [0.57, 0.36, 0.28, 0.23],
        "collectionType":   [0.10, 0.07, 0.05, 0.01],
    },
    "Metapath2Vec": {
        "name":             [0.10, 0.08, 0.09, 0.20],
        "bioActivity":      [0.27, 0.17, 0.13, 0.12],
        "collectionSpecie": [0.40, 0.41, 0.42, 0.44],
        "collectionSite":   [0.40, 0.42, 0.42, 0.40],
        "collectionType":   [0.28, 0.22, 0.19, 0.19],
    },
    "EPHEN": {
        "name":             [0.09, 0.02, 0.03, 0.04],
        "bioActivity":      [0.55, 0.57, 0.60, 0.64],
        "collectionSpecie": [0.36, 0.24, 0.29, 0.30],
        "collectionSite":   [0.53, 0.52, 0.55, 0.55],
        "collectionType":   [0.71, 0.66, 0.75, 0.75],
    },
}

# ── Text encoders (for cosine baselines + BERT-init graph models) ─────────────
ENCODER_MODELS = {
    "scibert":    "allenai/scibert_scivocab_uncased",
    "pubmedbert": "microsoft/BiomedNLP-BiomedBERT-base-uncased-abstract-fulltext",
}
# Which encoder initialises the BERT-based graph models
GRAPH_INIT_ENCODER = "scibert"   # change to "pubmedbert" to try that instead
BATCH_SIZE  = 16
MAX_SEQ_LEN = 512

# ── All models in the final result table ──────────────────────────────────────
# Cosine baselines (one per encoder — pure text similarity, no graph)
COSINE_MODELS = ["cosine_scibert", "cosine_pubmedbert"]

# Structure-only graph models (no BERT features)
STRUCTURE_MODELS = ["node2vec", "metapath2vec", "ephen"]

# BERT-initialised graph models (use GRAPH_INIT_ENCODER node features)
BERT_GRAPH_MODELS = ["rgcn", "rotate", "transe", "complex", "graphsage"]

# Ensemble (fuses all BERT_GRAPH_MODELS + best cosine)
ENSEMBLE_MODELS = ["ensemble"]

ALL_MODELS = COSINE_MODELS + STRUCTURE_MODELS + BERT_GRAPH_MODELS + ENSEMBLE_MODELS

# ── R-GCN hyperparameters ───────────────────────────────────────────────────
RGCN_HIDDEN    = 256
RGCN_OUT       = 256
RGCN_LAYERS    = 2
RGCN_DROPOUT   = 0.2
RGCN_LR        = 1e-3
RGCN_EPOCHS    = 300
RGCN_NEG_RATIO = 5

# ── RotatE hyperparameters ──────────────────────────────────────────────────
ROTATE_DIM    = 256
ROTATE_LR     = 1e-3
ROTATE_EPOCHS = 400
ROTATE_NEG    = 64
ROTATE_MARGIN = 6.0
ROTATE_BATCH  = 256

# ── TransE hyperparameters ──────────────────────────────────────────────────
TRANSE_DIM    = 256
TRANSE_LR     = 1e-3
TRANSE_EPOCHS = 400
TRANSE_NEG    = 64
TRANSE_MARGIN = 2.0
TRANSE_BATCH  = 256
TRANSE_NORM   = 2

# ── ComplEx hyperparameters ─────────────────────────────────────────────────
COMPLEX_DIM    = 256
COMPLEX_LR     = 1e-3
COMPLEX_EPOCHS = 400
COMPLEX_NEG    = 64
COMPLEX_BATCH  = 256
COMPLEX_REG    = 1e-3

# ── Node2Vec hyperparameters (structure-only) ───────────────────────────────
N2V_DIM        = 128   # smaller dim — no BERT init, purely structural
N2V_WALK_LEN   = 80
N2V_NUM_WALKS  = 10
N2V_P          = 1.0
N2V_Q          = 0.5
N2V_WINDOW     = 10
N2V_EPOCHS     = 5
N2V_WORKERS    = 4
N2V_MIN_COUNT  = 1

# ── Metapath2Vec hyperparameters (structure-only) ───────────────────────────
M2V_DIM        = 128
M2V_WALK_LEN   = 100
M2V_NUM_WALKS  = 5
M2V_WINDOW     = 5
M2V_EPOCHS     = 5
M2V_WORKERS    = 4
M2V_MIN_COUNT  = 1
M2V_NEG_SAMPLE = 5

# ── EPHEN hyperparameters (structure-only + optional text) ──────────────────
EPHEN_DIM         = 256
EPHEN_HEAT_T      = 5.0
EPHEN_K_EIGEN     = 128
EPHEN_NORM_EMB    = True

# ── GraphSAGE hyperparameters (BERT-initialised) ─────────────────────────────
SAGE_HIDDEN   = 256
SAGE_OUT      = 256
SAGE_LAYERS   = 2
SAGE_DROPOUT  = 0.2
SAGE_LR       = 1e-3
SAGE_EPOCHS   = 300
SAGE_NEG      = 5
SAGE_MARGIN   = 2.0
SAGE_SAMPLE_K = 15

# ── Frequency calibration ────────────────────────────────────────────────────
FREQ_PRIOR_POW = 0.3

# ── Random seed ──────────────────────────────────────────────────────────────
RANDOM_SEED = 42
