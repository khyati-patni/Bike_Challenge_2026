"""
stage5_natuke_stages.py
────────────────────────
NatUKE 4-stage evaluation with the correct model architecture.

MODEL GROUPS:
  1. Cosine baselines (no graph, no training):
       cosine_scibert    — SciBERT abstract embedding cosine similarity
       cosine_pubmedbert — PubMedBERT abstract embedding cosine similarity

  2. Structure-only graph models (no BERT, pure KG topology):
       node2vec          — biased random walks
       metapath2vec      — typed metapath walks
       ephen             — spectral heat-kernel

  3. BERT-initialised graph models (SciBERT node features):
       rgcn              — R-GCN message passing
       rotate            — RotatE complex rotation
       transe            — TransE translation
       complex           — ComplEx bilinear
       graphsage         — GraphSAGE mean aggregation

  4. Ensemble (fuses group 3 + best cosine)

STAGES (NatUKE protocol):
  1st: 20% train / 80% test
  2nd: 40% train / 60% test
  3rd: 60% train / 40% test
  4th: 80% train / 20% test

Each stage trains graph models from scratch on that stage's training edges.
Cosine baselines need no training — just load precomputed BERT embeddings.

Hits@k for k in {1, 5, 20, 50}.

Output:
  results/stage_results.json    — all models × tasks × stages
  results/stage_summary.json    — formatted for LaTeX table
"""
import argparse, json, pathlib, sys, time
import numpy as np
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import (
    TASKS, DATA_DIR, RES_DIR,
    STAGES, STAGE_NAMES, EVAL_K_VALUES, ALL_MODELS,
    NATUKE_TABLE, RANDOM_SEED, GRAPH_INIT_ENCODER,
)
from stage3a_rgcn         import train_rgcn
from stage3b_rotate       import train_rotate
from stage3c_transe       import train_transe
from stage3d_node2vec     import train_node2vec
from stage3e_metapath2vec import train_metapath2vec
from stage3f_ephen        import train_ephen
from stage3g_graphsage    import train_graphsage
from stage3h_complex      import train_complex
from stage4_evaluate      import evaluate_one_stage

GRAPH_FILE = DATA_DIR / "graph.json"


# ── Load BERT embeddings once (cosine baselines) ──────────────────────────────

def load_bert_embeddings():
    """
    Load precomputed SciBERT and PubMedBERT embeddings.
    These are used as-is for cosine baselines, and to initialise graph models.
    Returns dict: {enc_name: (doi_emb, label_emb)} or None if not found.
    """
    result = {}
    for enc in ["scibert", "pubmedbert"]:
        doi_path   = DATA_DIR / f"{enc}_doi_embeddings.npy"
        label_path = DATA_DIR / f"{enc}_label_embeddings.npy"
        if doi_path.exists() and label_path.exists():
            result[enc] = (
                np.load(doi_path),
                np.load(label_path),
            )
            print(f"  [embeddings] loaded {enc}: "
                  f"doi={result[enc][0].shape}  label={result[enc][1].shape}")
        else:
            print(f"  [embeddings] {enc} not found — run stage1 first")
    return result


# ── Data splitting ────────────────────────────────────────────────────────────

def load_combined(task):
    cfg = TASKS[task]
    tr  = pd.read_csv(cfg["train"])
    te  = pd.read_csv(cfg["test"])
    return pd.concat([tr, te], ignore_index=True).drop_duplicates(["node", "neighbor"])


def make_stage_splits(seed=RANDOM_SEED):
    """Split all DOIs into 4 (train, test) pairs per NatUKE ratios."""
    all_dois = set()
    for task in TASKS:
        all_dois.update(load_combined(task)["node"].unique())
    dois     = sorted(all_dois)
    shuffled = np.random.default_rng(seed).permutation(dois)
    n = len(shuffled)
    splits = []
    for train_ratio, _ in STAGES:
        n_train = max(1, int(round(n * train_ratio)))
        splits.append((set(shuffled[:n_train]), set(shuffled[n_train:])))
    return splits


def build_stage_edges(train_dois, graph):
    node_index = graph["node_index"]
    doi_gids   = {node_index[d] for d in train_dois if d in node_index}
    stage_edges = {task: [] for task in TASKS}
    for task in TASKS:
        for h, t in graph["train_edges"][task] + graph["test_edges"][task]:
            if h in doi_gids:
                stage_edges[task].append([h, t])
    return stage_edges


def build_test_rows(test_dois):
    return {
        task: load_combined(task).pipe(
            lambda df: df[df["node"].isin(test_dois)].reset_index(drop=True))
        for task in TASKS
    }


# ── Main ──────────────────────────────────────────────────────────────────────

def run_stages(seed=RANDOM_SEED, models=None):
    if models is None:
        models = ALL_MODELS

    print(f"\n{'═'*70}")
    print(f"  BiKE v2 · NatUKE 4-Stage Evaluation")
    print(f"  Graph models init encoder: {GRAPH_INIT_ENCODER.upper()}")
    print(f"  Models: {models}")
    print(f"{'═'*70}")

    # Load BERT embeddings (used for cosine baselines + BERT-graph init)
    bert_embs = load_bert_embeddings()

    graph  = json.loads(GRAPH_FILE.read_text())
    splits = make_stage_splits(seed)

    RES_DIR.mkdir(exist_ok=True)

    # raw_results[model][task][stage_name] = {hits: {k: v}, mrr: v}
    raw_results = {m: {t: {} for t in TASKS} for m in ALL_MODELS}

    for stage_idx, (train_dois, test_dois) in enumerate(splits):
        sname = STAGE_NAMES[stage_idx]
        ratio = STAGES[stage_idx][0]
        t0    = time.time()

        print(f"\n{'─'*60}")
        print(f"  Stage {sname}  ({int(ratio*100)}% train / {int((1-ratio)*100)}% test)")
        print(f"  train_dois={len(train_dois)}  test_dois={len(test_dois)}")
        print(f"{'─'*60}")

        stage_train_edges = build_stage_edges(train_dois, graph)
        stage_test_rows   = build_test_rows(test_dois)

        if min(len(df) for df in stage_test_rows.values()) < 1:
            print(f"  [skip {sname}] no test rows"); continue

        stage_dir = RES_DIR / f"stage_{sname}"
        stage_dir.mkdir(parents=True, exist_ok=True)

        # ── Structure-only models (no BERT, no enc_name) ─────────────────────
        node2vec_node = metapath2vec_node = ephen_node = None

        if "node2vec" in models:
            print(f"  [{sname}] Node2Vec (structure-only) ...")
            node2vec_node = train_node2vec(
                None, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if "metapath2vec" in models:
            print(f"  [{sname}] Metapath2Vec (structure-only) ...")
            metapath2vec_node = train_metapath2vec(
                None, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if "ephen" in models:
            print(f"  [{sname}] EPHEN (structure-only) ...")
            ephen_node = train_ephen(
                None, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        # ── BERT-initialised graph models (use GRAPH_INIT_ENCODER) ───────────
        rotate_ent = rotate_rel = None
        rgcn_node  = rgcn_rel  = None
        transe_ent = transe_rel = None
        complex_ent = complex_rel = None
        graphsage_node = graphsage_rel = None

        enc = GRAPH_INIT_ENCODER  # "scibert" by default

        if any(m in models for m in ["rotate", "ensemble"]):
            print(f"  [{sname}] RotatE (init: {enc}) ...")
            rotate_ent, rotate_rel = train_rotate(
                enc, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if any(m in models for m in ["rgcn", "ensemble"]):
            print(f"  [{sname}] R-GCN (init: {enc}) ...")
            rgcn_node, rgcn_rel = train_rgcn(
                enc, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if any(m in models for m in ["transe", "ensemble"]):
            print(f"  [{sname}] TransE (init: {enc}) ...")
            transe_ent, transe_rel = train_transe(
                enc, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if any(m in models for m in ["complex", "ensemble"]):
            print(f"  [{sname}] ComplEx (init: {enc}) ...")
            complex_ent, complex_rel = train_complex(
                enc, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        if any(m in models for m in ["graphsage", "ensemble"]):
            print(f"  [{sname}] GraphSAGE (init: {enc}) ...")
            graphsage_node, graphsage_rel = train_graphsage(
                enc, stage_dir,
                train_edges_override=stage_train_edges, verbose=False)

        # ── Evaluate ──────────────────────────────────────────────────────────
        print(f"  [{sname}] evaluating all models ...")

        sci_doi, sci_lbl   = bert_embs.get("scibert",    (None, None))
        pub_doi, pub_lbl   = bert_embs.get("pubmedbert", (None, None))

        stage_results = evaluate_one_stage(
            # Cosine baselines
            scibert_doi_emb=sci_doi,     scibert_label_emb=sci_lbl,
            pubmedbert_doi_emb=pub_doi,  pubmedbert_label_emb=pub_lbl,
            # Structure-only
            node2vec_node=node2vec_node,
            metapath2vec_node=metapath2vec_node,
            ephen_node=ephen_node,
            # BERT-init graph
            rotate_ent=rotate_ent,   rotate_rel=rotate_rel,
            rgcn_node=rgcn_node,     rgcn_rel=rgcn_rel,
            transe_ent=transe_ent,   transe_rel=transe_rel,
            complex_ent=complex_ent, complex_rel=complex_rel,
            graphsage_node=graphsage_node, graphsage_rel=graphsage_rel,
            train_edges_override=stage_train_edges,
            test_rows_override=stage_test_rows,
        )

        for model_name, task_dict in stage_results.items():
            if model_name not in raw_results: continue
            for task, metrics in task_dict.items():
                raw_results[model_name][task][sname] = metrics

        print(f"  [{sname}] done in {time.time()-t0:.1f}s")
        (RES_DIR / "stage_results.json").write_text(json.dumps(raw_results, indent=2))

    return raw_results


# ── Summary builder ───────────────────────────────────────────────────────────

def build_summary(raw_results):
    """
    Build summary dict for easy LaTeX table population.
    summary[model][task][stage] = {hits@k: value for k in EVAL_K_VALUES, mrr: value}
    Also adds primary_k_val for quick NatUKE comparison.
    """
    summary = {}
    for model, task_dict in raw_results.items():
        summary[model] = {}
        for task, stage_dict in task_dict.items():
            pk = TASKS[task]["primary_k"]
            summary[model][task] = {}
            for sname, metrics in stage_dict.items():
                hits = metrics.get("hits", {})
                summary[model][task][sname] = {
                    "hits": {str(k): hits.get(k, hits.get(str(k), 0.0))
                             for k in EVAL_K_VALUES},
                    "mrr":  metrics.get("mrr", 0.0),
                    "primary_k":     pk,
                    "primary_k_val": hits.get(pk, hits.get(str(pk), 0.0)),
                }
    return summary


def print_results_table(summary):
    """Print NatUKE-style table: rows=properties, cols=stages, one block per model."""
    prop_order = ["name", "bioActivity", "collectionSpecie",
                  "collectionSite", "collectionType"]
    short = {t: TASKS[t]["short"] for t in TASKS}

    print(f"\n{'═'*80}")
    print(f"  BiKE v2 RESULTS  (Hits@primary_k per property per stage)")
    print(f"  C=name(k=50) B=bioActivity(k=5) S=specie(k=50) "
          f"L=site(k=20) T=type(k=1)")
    print(f"{'═'*80}")

    for model, task_dict in summary.items():
        print(f"\n  ┌─ {model} ─────────────────────────────────┐")
        print(f"  │ {'Prop':<5}  {'1st':>6}  {'2nd':>6}  {'3rd':>6}  {'4th':>6} │")
        print(f"  │ {'─'*35} │")
        for task in prop_order:
            if task not in task_dict: continue
            row = [f"{task_dict[task].get(sn, {}).get('primary_k_val', 0):.2f}"
                   for sn in STAGE_NAMES]
            print(f"  │ {short[task]:<5}  {'  '.join(row)} │")
        print(f"  └{'─'*40}┘")

    print(f"\n  ┌─ NatUKE baselines ──────────────────────────┐")
    for method, task_vals in NATUKE_TABLE.items():
        print(f"\n  │ [{method}]")
        for task in prop_order:
            if task not in task_vals: continue
            row = [f"{v:.2f}" for v in task_vals[task]]
            print(f"  │ {short[task]:<5}  {'  '.join(row)}")
    print(f"  └{'─'*40}┘")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed",   type=int, default=RANDOM_SEED)
    ap.add_argument("--models", nargs="+", default=ALL_MODELS)
    args = ap.parse_args()

    raw     = run_stages(seed=args.seed, models=args.models)
    summary = build_summary(raw)

    (RES_DIR / "stage_results.json").write_text(json.dumps(raw, indent=2))
    (RES_DIR / "stage_summary.json").write_text(json.dumps(summary, indent=2))
    print_results_table(summary)
    print(f"\n[done] results → {RES_DIR / 'stage_results.json'}")
