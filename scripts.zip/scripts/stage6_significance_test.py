"""
stage6_significance_test.py
─────────────────────────────
Statistical tests against NatUKE baselines.
Reads results/stage_results.json produced by stage5_natuke_stages.py.

(A) Sign test: BiKE model vs NatUKE reference across 4 stages
(B) Model ranking: which BiKE model is best per task
"""
import json, pathlib, sys
import numpy as np
from scipy import stats

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import TASKS, RES_DIR, NATUKE_TABLE, STAGE_NAMES, ALL_MODELS, EVAL_K_VALUES

SIG_LEVEL = 0.05
RESULTS_FILE = RES_DIR / "stage_results.json"


def load_stage_scores(raw, model, task, k):
    scores = []
    for sname in STAGE_NAMES:
        d = raw.get(model, {}).get(task, {}).get(sname, {})
        hits = d.get("hits", {})
        v = hits.get(k, hits.get(str(k)))
        if v is not None: scores.append(float(v))
    return scores


def sign_test(our_scores, ref_score):
    s = np.array(our_scores)
    n_above = int((s > ref_score).sum())
    n_below = int((s < ref_score).sum())
    n_total = n_above + n_below
    if n_total == 0: return {"p": 1.0, "sig": False}
    result = stats.binomtest(n_above, n_total, p=0.5, alternative="greater")
    return {"n_above": n_above, "n_below": n_below,
            "our_mean": float(s.mean()), "our_std": float(s.std()),
            "ref": ref_score, "p": float(result.pvalue),
            "sig": bool(result.pvalue < SIG_LEVEL),
            "beats_mean": bool(s.mean() > ref_score)}


def main():
    if not RESULTS_FILE.exists():
        print(f"[stage6] {RESULTS_FILE} not found — run stage5 first"); return

    raw = json.loads(RESULTS_FILE.read_text())
    lines = ["BiKE v2 — Significance Report vs NatUKE",
             "=" * 70, f"α = {SIG_LEVEL}", ""]

    lines.append("Sign test: BiKE stage scores vs NatUKE primary-k references")
    lines.append("-" * 70)

    best_per_task = {}
    for task, cfg in TASKS.items():
        pk = cfg["primary_k"]
        best_per_task[task] = {"model": None, "mean": -1}
        lines.append(f"\n  Task: {task}  (primary k={pk})")

        # NatUKE reference = best NatUKE method at 3rd stage
        natuke_ref = max(
            v[task][2] for v in NATUKE_TABLE.values() if task in v
        ) if NATUKE_TABLE else None

        for model in ALL_MODELS:
            scores = load_stage_scores(raw, model, task, pk)
            if not scores: continue
            mean = float(np.mean(scores))
            if mean > best_per_task[task]["mean"]:
                best_per_task[task] = {"model": model, "mean": mean}
            if natuke_ref is not None:
                r = sign_test(scores, natuke_ref)
                sig = "✓" if r["sig"] else " "
                beat = ">" if r["beats_mean"] else "<="
                lines.append(
                    f"    {model:<20}  H@{pk}: {mean:.3f}±{np.std(scores):.3f} "
                    f"{beat} NatUKE={natuke_ref:.2f}  p={r['p']:.3f}  {sig}")

    lines.append("\n\nBest model per task (by mean primary-k across 4 stages):")
    lines.append("-" * 70)
    for task, info in best_per_task.items():
        lines.append(f"  {task:<22}  {info['model']:<20}  mean={info['mean']:.3f}")

    text = "\n".join(lines)
    (RES_DIR / "significance_report.txt").write_text(text)
    print(text)
    print(f"\n[stage6 done] → {RES_DIR / 'significance_report.txt'}")


if __name__ == "__main__":
    main()
