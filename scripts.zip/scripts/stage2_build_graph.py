"""
stage2_build_graph.py
─────────────────────
Builds a multi-relational heterogeneous knowledge graph from all 5
train CSVs, shared across encoder experiments.

Node types:
  doi          — paper nodes (shared across all relation types → cross-task transfer)
  label        — property value nodes (one pool across all 5 tasks)

Relation types (5):
  bioActivity, collectionSite, collectionSpecie, collectionType, name

The graph stores raw train_edges and test_edges for use in K-fold CV
(each fold re-partitions at the CSV level, but the full node universe
is registered so embeddings are aligned).

Output:
  data/graph.json
"""
import json, pathlib, sys
import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import TASKS, DATA_DIR

OUT = DATA_DIR / "graph.json"


def main():
    doi_nodes   = set()
    label_nodes = set()

    for cfg in TASKS.values():
        for split in ("train", "test"):
            df = pd.read_csv(cfg[split])
            doi_nodes.update(df["node"].unique())
            label_nodes.update(df["neighbor"].unique())

    doi_list   = sorted(doi_nodes)
    label_list = sorted(label_nodes)

    # Global node index: DOIs first, labels second
    node_index = {}
    for i, d in enumerate(doi_list):
        node_index[d] = i
    offset = len(doi_list)
    for i, l in enumerate(label_list):
        node_index[l] = offset + i

    n_nodes = len(node_index)
    node_type = {}
    for d in doi_list:   node_type[node_index[d]] = "doi"
    for l in label_list: node_type[node_index[l]] = "label"

    rel_index   = {task: i for i, task in enumerate(TASKS.keys())}
    train_edges = {task: [] for task in TASKS}
    test_edges  = {task: [] for task in TASKS}

    for task, cfg in TASKS.items():
        for split, store in [("train", train_edges), ("test", test_edges)]:
            df = pd.read_csv(cfg[split])
            for _, row in df.iterrows():
                h = node_index.get(row["node"])
                t = node_index.get(row["neighbor"])
                if h is not None and t is not None:
                    store[task].append([h, t])

    print(f"[stage2] graph summary")
    print(f"  nodes    : {n_nodes}  (doi={len(doi_list)}, labels={len(label_list)})")
    print(f"  relations: {len(rel_index)}")
    for task in TASKS:
        print(f"    {task:<22}  train={len(train_edges[task]):4d}  test={len(test_edges[task]):4d}")

    graph = {
        "node_index":   node_index,
        "node_type":    {str(v): t for v, t in node_type.items()},
        "rel_index":    rel_index,
        "n_nodes":      n_nodes,
        "n_relations":  len(rel_index),
        "train_edges":  train_edges,
        "test_edges":   test_edges,
        "doi_list":     doi_list,
        "label_list":   label_list,
    }

    OUT.write_text(json.dumps(graph))
    print(f"[stage2 done] graph.json written  ({OUT.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
