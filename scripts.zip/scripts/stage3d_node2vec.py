"""
stage3d_node2vec.py — Structure-only Node2Vec (no BERT features).
Matches the original NatUKE Node2Vec baseline exactly.
Learns embeddings purely from KG edge structure via biased random walks.
"""
import argparse, json, pathlib, sys
import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import DATA_DIR, RES_DIR, N2V_DIM, N2V_WALK_LEN, N2V_NUM_WALKS
from config import N2V_P, N2V_Q, N2V_WINDOW, N2V_EPOCHS, N2V_WORKERS, N2V_MIN_COUNT

GRAPH_FILE = DATA_DIR / "graph.json"


def build_adj(graph, edges_override=None):
    edges = edges_override or graph["train_edges"]
    n = graph["n_nodes"]
    adj = {i: [] for i in range(n)}
    for task_edges in edges.values():
        for h, t in task_edges:
            adj[h].append(t)
            adj[t].append(h)
    for node in adj:
        adj[node] = list(set(adj[node]))
    return adj


def walk(adj, start, walk_len, p, q, rng):
    w = [start]
    if not adj[start]: return w
    w.append(rng.choice(adj[start]))
    for _ in range(walk_len - 2):
        cur, prev = w[-1], w[-2]
        nbrs = adj[cur]
        if not nbrs: break
        weights = []
        for nb in nbrs:
            if nb == prev:           weights.append(1.0 / p)
            elif nb in adj[prev]:    weights.append(1.0)
            else:                    weights.append(1.0 / q)
        weights = np.array(weights, dtype=np.float32)
        weights /= weights.sum()
        w.append(rng.choice(nbrs, p=weights))
    return w


def train_node2vec(enc_name, out_dir, train_edges_override=None, verbose=True):
    """
    enc_name is ignored — Node2Vec is structure-only.
    Kept for interface compatibility with stage5.
    """
    from gensim.models import Word2Vec
    graph   = json.loads(GRAPH_FILE.read_text())
    n_nodes = graph["n_nodes"]
    if verbose: print(f"[Node2Vec] structure-only  n_nodes={n_nodes}")

    adj = build_adj(graph, train_edges_override)
    rng = np.random.default_rng(42)
    nodes = [n for n in range(n_nodes) if adj[n]]

    walks = []
    for _ in range(N2V_NUM_WALKS):
        for node in rng.permutation(nodes):
            w = walk(adj, int(node), N2V_WALK_LEN, N2V_P, N2V_Q, rng)
            if len(w) > 1: walks.append(w)

    str_walks = [[str(n) for n in w] for w in walks]
    model = Word2Vec(sentences=str_walks, vector_size=N2V_DIM, window=N2V_WINDOW,
                     min_count=N2V_MIN_COUNT, sg=1, workers=N2V_WORKERS,
                     epochs=N2V_EPOCHS, seed=42)

    emb = np.zeros((n_nodes, N2V_DIM), dtype=np.float32)
    for i in range(n_nodes):
        key = str(i)
        if key in model.wv: emb[i] = model.wv[key]
        else: emb[i] = np.random.randn(N2V_DIM).astype(np.float32) * 0.01

    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "node2vec_node_emb.npy", emb)
    if verbose: print(f"[Node2Vec done] shape={emb.shape}")
    return emb


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", type=pathlib.Path, default=RES_DIR)
    args = ap.parse_args()
    train_node2vec(None, args.out_dir, verbose=True)
